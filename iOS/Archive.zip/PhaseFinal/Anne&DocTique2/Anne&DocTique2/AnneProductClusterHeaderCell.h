//
//  AnneProductClusterHeaderCell.h
//  MultiProductViewer
//
//  Created by JN on 2014-3-19.
//  Copyright (c) 2014 thoughtbot, inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnneProductClusterHeaderCell : UICollectionReusableView

@property (copy, nonatomic) NSString *headerText;


@end
