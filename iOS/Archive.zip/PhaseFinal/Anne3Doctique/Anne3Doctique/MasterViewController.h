//
//  MasterViewController.h
//  Demo2
//
//  Created by Kapi on 23/05/2014.
//  Copyright (c) 2014 Kapi. All rights reserved.
//

#import <UIKit/UIKit.h>

//@interface AnneViewController : UIViewController

//@property (nonatomic, strong) UILabel * label;

//@end

@interface MasterViewController : UITableViewController
{
    NSMutableArray *maListe;
}
@end