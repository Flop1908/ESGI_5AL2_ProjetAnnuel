#import <Foundation/Foundation.h>

@interface VDMEntryCellBackground : UIView {

}

@end
