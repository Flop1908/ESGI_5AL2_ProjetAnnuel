//
//  main.m
//  Anne3Doctique
//
//  Created by Kapi on 19/06/2014.
//  Copyright (c) 2014 Lionel. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AnneAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AnneAppDelegate class]));
    }
}
