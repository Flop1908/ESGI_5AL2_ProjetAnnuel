//
//  AnneMenuViewController.h
//  Demo2
//
//  Created by Kapi on 23/05/2014.
//  Copyright (c) 2014 Kapi. All rights reserved.
//

#import "AnneAirViewController.h"

@interface AnneMenuViewController : AnneAirViewController <AnneAirMenuDataSource, AnneAirMenuDelegate>

@end
