//
//  AnneSessionView.h
//  Anne&DocTique
//
//  Created by Kapi on 23/05/2014.
//  Copyright (c) 2014 Kapi. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kHeaderTitleHeight   80

@interface AnneSessionView : UIView

@property (nonatomic, strong) UIButton * button;
@property (nonatomic, strong) UIView   * containView;

@end
