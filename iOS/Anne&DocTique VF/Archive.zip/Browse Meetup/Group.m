//
//  Group.m
//  Anne&DocTique
//
//  Created by Kapi on 02/03/2014.
//  Copyright (c) 2014 Lionel. All rights reserved.
//

#import "Group.h"

@implementation Group

@end
