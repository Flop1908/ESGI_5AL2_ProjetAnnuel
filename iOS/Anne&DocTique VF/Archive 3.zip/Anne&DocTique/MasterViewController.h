//
//  MasterViewController.h
//  Anne&DocTique
//
//  Created by Kapi on 29/01/2014.
//  Copyright (c) 2014 Lionel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface MasterViewController : UITableViewController

@end
