//
//  DetailCell.m
//  Anne&DocTique
//
//  Created by Kapi on 29/04/2014.
//  Copyright (c) 2014 Lionel. All rights reserved.
//

#import "DetailCell.h"

@implementation DetailCell

@end
