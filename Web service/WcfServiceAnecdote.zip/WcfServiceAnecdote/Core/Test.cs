﻿namespace Core
{
    class Test
    {


    }
}
